# Coding-Patches
It is for Simplified coding
